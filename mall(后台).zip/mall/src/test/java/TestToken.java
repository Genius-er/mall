import com.auth0.jwt.interfaces.Claim;
import org.junit.Test;
import org.mousetailjuice.entity.User;
import org.mousetailjuice.util.JwtToken;

import java.util.HashMap;
import java.util.Map;

public class TestToken {
    @Test
    public void testCheckToken() {
        String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkYXRlIjoxNjA2MTA1MzA0LCJ1c2VybmFtZSI6Im1hc3Rlcm1hIn0.Fsbo-PjuM4W9MLNzqrBjN-TeB66SIuSfz5C55Nyy6Ko";
        Map<String, Claim> claimMap = JwtToken.verifyToken(token);
        if (claimMap != null) {
            System.out.println(claimMap.get("username").asString());
        }
    }

    @Test
    public void TestMap() {
        Map<String, String> map = new HashMap<>();
        map.put("aaa", null);
        System.out.println(map);

    }
}
