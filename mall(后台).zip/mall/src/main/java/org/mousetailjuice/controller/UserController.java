package org.mousetailjuice.controller;

import org.mousetailjuice.entity.Manager;
import org.mousetailjuice.entity.User;
import org.mousetailjuice.service.UserService;
import org.mousetailjuice.status.LoginStatus;
import org.mousetailjuice.status.RegisterStatus;
import org.mousetailjuice.util.ResponseData;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/user")
public class UserController {
    @Resource
    private UserService userService;

    /**
     * 用户注册的controller
     * @param request
     * @return
     */
    @RequestMapping("/userRegister")
    @ResponseBody
    public Map<String, Object> userRegister(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        String phone = request.get("phone");
        if (username != null && password != null) {
            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            user.setPhone(phone);
            return userService.userRegister(user);
        }
        return ResponseData.response(RegisterStatus.REQUEST_ERROR_402.status, RegisterStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 用户登录的controller
     * @param request
     * @return
     */
    @RequestMapping("/userLogin")
    @ResponseBody
    public Map<String, Object> userLogin(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        if (username != null && password != null) {
            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            return userService.userLogin(user);
        }
        return ResponseData.response(LoginStatus.REQUEST_ERROR_402.status, LoginStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 用户注销的controller
     * @return
     */
    @RequestMapping("/userLogout")
    @ResponseBody
    public Map<String, Object> userLogout(@RequestHeader("token") String token) {
        return userService.userLogout(token);
     }


}
