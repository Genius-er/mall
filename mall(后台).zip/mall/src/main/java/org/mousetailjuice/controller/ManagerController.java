package org.mousetailjuice.controller;

import org.mousetailjuice.entity.Category;
import org.mousetailjuice.entity.Manager;
import org.mousetailjuice.entity.Product;
import org.mousetailjuice.entity.User;
import org.mousetailjuice.service.ManagerService;
import org.mousetailjuice.status.*;
import org.mousetailjuice.util.ResponseData;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

@Controller
@CrossOrigin
@RequestMapping("/manager")
public class ManagerController {
    @Resource
    private ManagerService managerService;

    /**
     * 管理员登录的controller
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/managerLogin")
    @ResponseBody
    public Map<String, Object> managerLogin(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        if (username != null && password != null) {
            Manager manager = new Manager();
            manager.setUsername(username);
            manager.setPassword(password);
            return managerService.managerLogin(manager);
        }
        return ResponseData.response(LoginStatus.REQUEST_ERROR_402.status, LoginStatus.REQUEST_ERROR_402.message, null);
    }


    /* ************************************** 对用户 ************************************** */
    /**
     * 分页查询所有用户的controller
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    @RequestMapping("/showAllUsers")
    @ResponseBody
    public Map<String, Object> showAllUsers(@RequestHeader("token") String token) {
        return managerService.showAllUsers(token);
    }

    /**
     * 修改用户状态的controller
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/setUserStatus")
    @ResponseBody
    public Map<String, Object> setUserStatus(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String userId = request.get("userId");
        String status = request.get("status");
        if (userId != null && status != null) {
            User user = new User();
            user.setUserId(Integer.parseInt(userId));
            user.setStatus(Integer.parseInt(status));
            return managerService.setUserStatus(user, token);
        }
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_402.status, ModifyStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 模糊查询用户的controller
     * @param token 管理员的token令牌
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/searchUser")
    @ResponseBody
    public Map<String, Object> searchUser(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String username = request.get("username");
        if (username != null) {
            User user = new User();
            user.setUsername(username);
            return managerService.searchUser(user, token);
        }
        return ResponseData.response(SearchStatus.REQUEST_ERROR_402.status, SearchStatus.REQUEST_ERROR_402.message, null);
    }

    /* ************************************** 对分类 ************************************** */
    /**
     * 分页查询所有一级分类的controller
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    @RequestMapping("/showAllCategories")
    @ResponseBody
    public Map<String, Object> showAllCategories(@RequestHeader("token") String token) {
        return managerService.showAllCategories(token);
    }

    /**
     * 删除分类的controller
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    @RequestMapping("/deleteCategory")
    @ResponseBody
    public Map<String, Object> deleteCategory(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String cateId = request.get("cateId");
        if (cateId != null) {
            Category category = new Category();
            category.setCateId(Integer.parseInt(cateId));
            return managerService.deleteCategory(category, token);
        }
        return ResponseData.response(DeleteStatus.REQUEST_ERROR_402.status, DeleteStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 添加分类的controller
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/addCategory")
    @ResponseBody
    public Map<String, Object> addCategory(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String name = request.get("name");
        String description = request.get("description");
        String parentName = request.get("parentName");

        if (name != null && description != null) {
            Category category = new Category();
            category.setName(name);
            category.setDescription(description);
            return managerService.addCategory(category, parentName, token);
        }
        return ResponseData.response(AddStatus.REQUEST_ERROR_402.status, AddStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 修改分类信息的controller
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/modifyCategory")
    @ResponseBody
    public Map<String, Object> modifyCategory(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String cateId = request.get("cateId");
        String name = request.get("name");
        String description = request.get("description");

        if (name != null && description != null) {
            Category category = new Category();
            category.setCateId(Integer.parseInt(cateId));
            category.setName(name);
            category.setDescription(description);
            return managerService.modifyCategory(category, token);
        }
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_402.status, ModifyStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 模糊查询分类的controller
     * @param token 管理员的token令牌
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/searchCategory")
    @ResponseBody
    public Map<String, Object> searchCategory(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String name = request.get("name");
        if (name != null) {
            Category category = new Category();
            category.setName(name);
            return managerService.searchCategory(category, token);
        }
        return ResponseData.response(SearchStatus.REQUEST_ERROR_402.status, SearchStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 查询一级分类下的二级分类的controller
     * @param token 管理员的token令牌
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/showSecCategory")
    @ResponseBody
    public Map<String, Object> showSecCategory(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String cateId = request.get("cateId");
        if (cateId != null) {
            Category category = new Category();
            category.setCateId(Integer.parseInt(cateId));
            return managerService.showSecCategory(category, token);
        }
        return ResponseData.response(SearchStatus.REQUEST_ERROR_402.status, SearchStatus.REQUEST_ERROR_402.message, null);
    }


    /* ************************************** 对商品 ************************************** */

    /**
     * 查询所有商品的controller
     * @param token
     * @return
     */
    @RequestMapping("/showAllProducts")
    @ResponseBody
    public Map<String, Object> showAllProducts(@RequestHeader("token") String token) {
        return managerService.showAllProducts(token);
    }

    /**
     * 上下架商品的controller
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/setProductStatus")
    @ResponseBody
    public Map<String, Object> setProductStatus(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String proId = request.get("proId");
        String status = request.get("status");
        if (proId != null && status != null) {
            Product product = new Product();
            product.setProId(Integer.parseInt(proId));
            product.setStatus(Integer.parseInt(status));
            return managerService.setProductStatus(product, token);
        }
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_402.status, ModifyStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 删除商品的controller
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    @RequestMapping("/deleteProduct")
    @ResponseBody
    public Map<String, Object> deleteProduct(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String proId = request.get("proId");
        if (proId != null) {
            Product product = new Product();
            product.setProId(Integer.parseInt(proId));
            return managerService.deleteProduct(product, token);
        }
        return ResponseData.response(DeleteStatus.REQUEST_ERROR_402.status, DeleteStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 添加商品的controller
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/addProduct")
    @ResponseBody
    public Map<String, Object> addProduct(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String cateName = request.get("cateName");
        String name = request.get("name");
        String mainImage = request.get("mainImage");
        String detail = request.get("detail");
        String price = request.get("price");
        String stock = request.get("stock");
        String status = request.get("status");

        if (cateName != null && name != null && price != null && stock != null) {
            Product product = new Product();
            product.setName(name);
            product.setMainImage(mainImage);
            product.setDetail(detail);
            product.setPrice(Double.parseDouble(price));
            product.setStock(Integer.parseInt(stock));
            product.setStatus(Integer.parseInt(status));
            return managerService.addProduct(product, cateName, token);
        }
        return ResponseData.response(AddStatus.REQUEST_ERROR_402.status, AddStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 上传图片的controller
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/uploadImage")
    @ResponseBody
    public Map<String, Object> uploadImage(@RequestHeader("token") String token, @RequestParam(value="file", required=false) MultipartFile image, HttpServletRequest request) {
        if (!image.isEmpty()) {
            //获得物理路径webapp所在路径
            String pathRoot = request.getSession().getServletContext().getRealPath("");
            return managerService.uploadImage(token, image, pathRoot);
        }
        return ResponseData.response(AddStatus.REQUEST_SUCCESS_300.status, AddStatus.REQUEST_SUCCESS_300.message, null);
    }


    /**
     * 模糊查询商品的controller
     * @param token 管理员的token令牌
     * @param request 请求数据
     * @return 响应数据
     */
    @RequestMapping("/searchProduct")
    @ResponseBody
    public Map<String, Object> searchProduct(@RequestHeader("token") String token, @RequestBody Map<String, String> request) {
        String name = request.get("name");
        if (name != null) {
            Product product = new Product();
            product.setName(name);
            return managerService.searchProduct(product, token);
        }
        return ResponseData.response(SearchStatus.REQUEST_ERROR_402.status, SearchStatus.REQUEST_ERROR_402.message, null);
    }



}
