package org.mousetailjuice.controller;

import org.mousetailjuice.service.ProductService;
import org.mousetailjuice.status.CommonStatus;
import org.mousetailjuice.util.ResponseData;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/product")
public class ProductController {
    @Resource
    private ProductService productService;

    /**
     * 获取热卖商品
     * @return
     */
    @RequestMapping("/getHotProducts")
    @ResponseBody
    public Map<String, Object> getHotProducts() {
        return productService.getHotProducts();
    }

    /**
     * 获取指定一级分类下的所有商品
     * @return
     */
    @RequestMapping("/getProductsByCateId")
    @ResponseBody
    public Map<String, Object> getProductsByCateId(@RequestBody Map<String, String> request) {
        String cateId = request.get("cateId");
        if (cateId != null) {
            return productService.getProductsByCateId(Integer.parseInt(cateId));
        }
        return ResponseData.response(CommonStatus.REQUEST_ERROR_402.status, CommonStatus.REQUEST_ERROR_402.message, null);
    }

    /**
     * 获取商品的信息
     * @return
     */
    @RequestMapping("/getProductInfo")
    @ResponseBody
    public Map<String, Object> getProductInfo(@RequestBody Map<String, String> request) {
        String proId = request.get("proId");
        if (proId != null) {
            return productService.getProductInfo(Integer.parseInt(proId));
        }
        return ResponseData.response(CommonStatus.REQUEST_ERROR_402.status, CommonStatus.REQUEST_ERROR_402.message, null);
    }
}
