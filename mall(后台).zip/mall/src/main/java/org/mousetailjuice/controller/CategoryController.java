package org.mousetailjuice.controller;

import org.mousetailjuice.service.CategoryService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/category")
public class CategoryController {
    @Resource
    private CategoryService categoryService;

    /**
     * 获取所有一级分类及其对应的二级分类
     * @return
     */
    @RequestMapping("/getAllCategories")
    @ResponseBody
    public Map<String, Object> getAllCategories() {
        return categoryService.getAllCategories();
    }




}
