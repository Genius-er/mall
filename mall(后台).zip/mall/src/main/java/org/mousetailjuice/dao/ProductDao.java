package org.mousetailjuice.dao;

import org.mousetailjuice.entity.Category;
import org.mousetailjuice.entity.Product;

import java.util.List;
import java.util.Map;

public interface ProductDao {

    /**
     * 选择热卖商品
     * @return
     */
    List<Map<String, Object>> selectHotProducts();

    /**
     * 根据一级分类的cateId选择属于一级分类的商品
     * @param cateId
     * @return
     */
    List<Map<String, Object>> selectProductByFirCateId(Integer cateId);

    /**
     * 根据二级分类的cateId选择属于二级分类的商品
     * @param cateId
     * @return
     */
    List<Map<String, Object>> selectProductBySecCateId(Integer cateId);

    /**
     * 根据商品proId选择商品
     * @param proId
     * @return
     */
    Map<String, Object> selectProductByProId(Integer proId);

    /**
     * 检查传来的是一级分类还是二级分类
     * @param cateId
     * @return
     */
    Category checkCateLevel(Integer cateId);
}
