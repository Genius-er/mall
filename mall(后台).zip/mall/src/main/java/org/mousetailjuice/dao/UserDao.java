package org.mousetailjuice.dao;

import org.mousetailjuice.entity.User;

import java.util.List;
import java.util.Map;

public interface UserDao {
    /**
     * 注册时选择用户，用于检查用户名是否重复
     * @param user
     * @return
     */
    List<User> registerSelectUser(User user);

    /**
     * 登录时选择用户，用于验证用户名和密码
     * @param user
     * @return
     */
    List<User> LoginSelectUser(User user);

    /**
     * 更新用户的token
     * @param user
     * @return
     */
    int updateToken(User user);

    /**
     * 插入用户，即用户注册
     * @param user
     * @return
     */
    int insertUser(User user);

}
