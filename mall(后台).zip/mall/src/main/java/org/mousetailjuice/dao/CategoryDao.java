package org.mousetailjuice.dao;

import org.mousetailjuice.entity.Category;
import org.mousetailjuice.entity.Product;

import java.util.List;
import java.util.Map;

public interface CategoryDao {

    /**
     * 选择所有一级分类
     * @return
     */
    List<Map<String, Object>> selectAllFirstCategories();

    /**
     * 根据一级分类的cateId选择对应的二级分类
     * @param cateId
     * @return
     */
    List<Map<String, Object>> selectSecondCategories(Integer cateId);


}
