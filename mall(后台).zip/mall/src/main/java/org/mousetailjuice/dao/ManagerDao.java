package org.mousetailjuice.dao;

import org.mousetailjuice.entity.Category;
import org.mousetailjuice.entity.Manager;
import org.mousetailjuice.entity.Product;
import org.mousetailjuice.entity.User;

import java.util.List;

public interface ManagerDao {
    /**
     * 从数据库选择管理员
     * @param manager 管理员对象
     * @return 内容为管理员对象的集合
     */
    List<Manager> selectManager(Manager manager);

    /**
     * 更新管理员的token
     * @param manager 管理员对象
     * @return 受影响的记录条数
     */
    int updateToken(Manager manager);

    /**
     * 选择所有用户
     * @return 内容为用户对象的集合
     */
    List<User> selectAllUsers();

    /**
     * 更新用户状态
     * @param user 用户对象
     * @return 受影响的记录条数
     */
    int updateUserStatus(User user);

    /**
     * 模糊查询用户
     * @param user 用户对象
     * @return 内容为用户对象的集合
     */
    List<User> selectUserLike(User user);

    /**
     * 选择所有一级分类信息
     * @return 内容为分类信息的集合
     */
    List<Category> selectFirstCategories();

    /**
     * 根据分类cateId得到该分类的信息
     * @param category 分类对象
     * @return 分类对象
     */
    Category selectCategoryById(Category category);

    /**
     * 删除二级分类
     * @param category 分类对象
     * @return 分类对象
     */
    int deleteSecondCategory(Category category);

    /**
     * 删除一级分类
     * @param category 分类对象
     * @return 分类对象
     */
    int deleteFirstCategory(Category category);

    /**
     * 选择所有商品
     * @return 分类对象
     */
    List<Product> selectAllProducts();

    /**
     * 添加分类时检查分类名是否已存在
     * @param category
     * @return
     */
    List<Category> insertCheckCategoryName(Category category);

    /**
     * 添加分类，包括父分类和子分类
     * @param category
     * @return
     */
    int insertCategory(Category category);

    /**
     * 根据分类名name得到分类信息
     * @param category
     * @return
     */
    Category selectCategoryByName(Category category);

    /**
     * 修改分类时检查分类名是否已存在
     * @param category
     * @return
     */
    List<Category> updateCheckCategoryName(Category category);

    /**
     * 修改分类信息
     * @param category
     * @return
     */
    int updateCategory(Category category);

    /**
     * 修改商品状态，上下架
     * @param product
     * @return
     */
    int updateProductStatus(Product product);

    /**
     * 删除商品
     * @param product
     * @return
     */
    int deleteProduct(Product product);

    /**
     * 添加商品
     * @param product
     * @return
     */
    int insertProduct(Product product);

    /**
     * 模糊查询分类
     * @param category
     * @return
     */
    List<Category> selectCategoryLike(Category category);

    /**
     * 模糊查询商品
     * @param product
     * @return
     */
    List<Product> selectProductLike(Product product);

    /**
     * 根据一级分类的id选择二级分类
     * @param category
     * @return
     */
    List<Category> selectSecCategory(Category category);

}
