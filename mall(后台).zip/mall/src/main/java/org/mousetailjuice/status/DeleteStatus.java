package org.mousetailjuice.status;

public enum DeleteStatus {
    REQUEST_SUCCESS_200("200", "删除成功"),
    REQUEST_ERROR_400("400", "删除失败"),
    REQUEST_ERROR_401("401", "token验证失败"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");

    public String status;
    public String message;

    DeleteStatus() {
    }

    DeleteStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "DeleteStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
