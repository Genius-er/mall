package org.mousetailjuice.status;

public enum LoginStatus {
    REQUEST_SUCCESS_200("200", "登录成功"),
    REQUEST_ERROR_400("400", "账户或密码错误，登录失败，请重试"),
    REQUEST_ERROR_401("401", "token更新失败，请重试"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");

    public String status;
    public String message;

    LoginStatus() {
    }

    LoginStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "LoginStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
