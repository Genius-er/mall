package org.mousetailjuice.status;

public enum AddStatus {
    REQUEST_SUCCESS_200("200", "添加成功"),
    REQUEST_SUCCESS_300("300", "图片文件内容为空，无法上传"),
    REQUEST_ERROR_400("400", "添加失败"),
    REQUEST_ERROR_400_1("400", "添加失败，分类名已被占用"),
    REQUEST_ERROR_400_2("400", "添加失败，找不到该一级分类"),
    REQUEST_ERROR_400_3("400", "商品添加失败，找不到该分类"),
    REQUEST_ERROR_401("401", "token验证失败"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");

    public String status;
    public String message;

    AddStatus() {
    }

    AddStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "AddStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
