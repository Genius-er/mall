package org.mousetailjuice.status;

public enum LogoutStatus {
    REQUEST_SUCCESS_200("200", "注销成功"),
    REQUEST_ERROR_400("400", "注销失败，请重试"),
    REQUEST_ERROR_401("401", "token验证失败，请重试"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");

    public String status;
    public String message;

    LogoutStatus() {
    }

    LogoutStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "LogoutStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
