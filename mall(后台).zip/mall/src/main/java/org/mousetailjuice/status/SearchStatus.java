package org.mousetailjuice.status;

public enum SearchStatus {
    REQUEST_SUCCESS_200("200", "查找成功"),
    REQUEST_SUCCESS_200_1("200", "用户名可用"),
    REQUEST_ERROR_400("400", "查找失败"),
    REQUEST_ERROR_400_1("400", "查找失败，找不到用户"),
    REQUEST_ERROR_400_2("400", "用户名已被占用"),
    REQUEST_ERROR_400_3("400", "查找失败，找不到分类"),
    REQUEST_ERROR_400_4("400", "查找失败，找不到商品"),
    REQUEST_ERROR_401("401", "token验证失败"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");

    public String status;
    public String message;

    SearchStatus() {
    }

    SearchStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "SearchStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
