package org.mousetailjuice.status;

public enum RegisterStatus {
    REQUEST_SUCCESS_200("200", "注册成功"),
    REQUEST_ERROR_400("400", "注册失败，请重试"),
    REQUEST_ERROR_400_1("400", "用户名重复，注册失败，请重试"),
    REQUEST_ERROR_401("401", "token更新失败，请重试"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");

    public String status;
    public String message;

    RegisterStatus() {
    }

    RegisterStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "RegisterStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
