package org.mousetailjuice.status;

public enum ModifyStatus {
    REQUEST_SUCCESS_200("200", "修改成功"),
    REQUEST_ERROR_400("400", "修改失败"),
    REQUEST_ERROR_400_1("400", "修改失败，用户名已被占用"),
    REQUEST_ERROR_400_2("400", "修改失败，分类名已被占用"),
    REQUEST_ERROR_401("401", "token验证失败"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");

    public String status;
    public String message;

    ModifyStatus() {
    }

    ModifyStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "ModifyStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
