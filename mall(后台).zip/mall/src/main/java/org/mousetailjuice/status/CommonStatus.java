package org.mousetailjuice.status;

public enum CommonStatus {
    REQUEST_SUCCESS_200("200", "请求成功"),
    REQUEST_ERROR_400("400", "请求失败"),
    REQUEST_ERROR_401("401", "token验证失败"),
    REQUEST_ERROR_402("402", "缺少必须参数，请检查");


    public String status;
    public String message;

    CommonStatus() {
    }

    CommonStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    @Override
    public String toString() {
        return "CommonStatus{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
