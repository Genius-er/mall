package org.mousetailjuice.service.Impl;

import org.mousetailjuice.dao.ManagerDao;
import org.mousetailjuice.entity.Category;
import org.mousetailjuice.entity.Manager;
import org.mousetailjuice.entity.Product;
import org.mousetailjuice.entity.User;
import org.mousetailjuice.service.ManagerService;
import org.mousetailjuice.status.*;
import org.mousetailjuice.util.JwtToken;
import org.mousetailjuice.util.ResponseData;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class ManagerServiceImpl implements ManagerService {
    @Resource
    private ManagerDao managerDao;

    @Override
    public Map<String, Object> managerLogin(Manager manager) {
        // 检查用户是否存在
        if (managerDao.selectManager(manager).size() != 0) {
            // 用户存在，更新用户的token
            String token = JwtToken.createToken(manager.getUsername());
            manager.setToken(token);
            int count = managerDao.updateToken(manager);
            // 检查更新token是否成功
            if (count > 0) {
                // token更新成功
                Map<String, Object> dataMap = new HashMap<>();
                dataMap.put("token", token);
                // 返回token
                return ResponseData.response(LoginStatus.REQUEST_SUCCESS_200.status, LoginStatus.REQUEST_SUCCESS_200.message, dataMap);
            }
            // token更新失败
            return ResponseData.response(LoginStatus.REQUEST_ERROR_401.status, LoginStatus.REQUEST_ERROR_401.message, null);
        }
        // 用户不存在
        return ResponseData.response(LoginStatus.REQUEST_ERROR_400.status, LoginStatus.REQUEST_ERROR_400.message, null);
    }

    @Override
    public Map<String, Object> showAllUsers(String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            List<User> userList = managerDao.selectAllUsers();
            // 返回用户列表
            return ResponseData.response(CommonStatus.REQUEST_SUCCESS_200.status, CommonStatus.REQUEST_SUCCESS_200.message, userList);
        }
        // token验证失败
        return ResponseData.response(CommonStatus.REQUEST_ERROR_401.status, CommonStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> setUserStatus(User user, String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            int count = managerDao.updateUserStatus(user);
            // 检查是否修改成功
            if (count > 0) {
                // 修改成功
                return ResponseData.response(ModifyStatus.REQUEST_SUCCESS_200.status, ModifyStatus.REQUEST_SUCCESS_200.message, null);
            }
            // 修改失败
            return ResponseData.response(ModifyStatus.REQUEST_ERROR_400.status, ModifyStatus.REQUEST_ERROR_400.message, null);
        }
        // token验证失败
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_401.status, ModifyStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> searchUser(User user, String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            List<User> userList = managerDao.selectUserLike(user);
            // 检查是否查找成功
            if (userList.size() != 0) {
                // 查找成功
                return ResponseData.response(SearchStatus.REQUEST_SUCCESS_200.status, SearchStatus.REQUEST_SUCCESS_200.message, userList);
            }
            // 查找失败，找不到用户
            return ResponseData.response(SearchStatus.REQUEST_ERROR_400_1.status, SearchStatus.REQUEST_ERROR_400_1.message, null);
        }
        // token验证失败
        return ResponseData.response(SearchStatus.REQUEST_ERROR_401.status, SearchStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> showAllCategories(String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            List<Category> categoryList = managerDao.selectFirstCategories();
            // 返回用户列表
            return ResponseData.response(CommonStatus.REQUEST_SUCCESS_200.status, CommonStatus.REQUEST_SUCCESS_200.message, categoryList);
        }
        // token验证失败
        return ResponseData.response(CommonStatus.REQUEST_ERROR_401.status, CommonStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> deleteCategory(Category category, String token) {
        if (JwtToken.verifyToken(token) != null) {
            // 先找到这个category的cateid和parentid，检测parentid是不是0
            Category currentCategory = managerDao.selectCategoryById(category);
            // TODO: 如果找不到这个类别
            int count;
            if (currentCategory.getParentId() != 0) {
                // 如果parentid不是0，直接删除
                count = managerDao.deleteSecondCategory(currentCategory);
            } else {
                // 如果parentid是0，删除此分类及其下的所有子分类
                count = managerDao.deleteFirstCategory(currentCategory);
            }
            if (count > 0) {
                return ResponseData.response(DeleteStatus.REQUEST_SUCCESS_200.status, DeleteStatus.REQUEST_SUCCESS_200.message, null);
            }
            return ResponseData.response(DeleteStatus.REQUEST_ERROR_400.status, DeleteStatus.REQUEST_ERROR_400.message, null);
        }
        // token验证失败
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_401.status, ModifyStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> showAllProducts(String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            List<Product> productList = managerDao.selectAllProducts();
            // 返回商品列表
            return ResponseData.response(CommonStatus.REQUEST_SUCCESS_200.status, CommonStatus.REQUEST_SUCCESS_200.message, productList);
        }
        // token验证失败
        return ResponseData.response(CommonStatus.REQUEST_ERROR_401.status, CommonStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> addCategory(Category category, String parentName, String token) {
        if (JwtToken.verifyToken(token) != null) {
            // 先检查要添加的分类名是否已存在
            List<Category> categoryList = managerDao.insertCheckCategoryName(category);
            if (categoryList.size() == 0) {
                // 分类名不存在，可以添加
                // 检查是否传入了父分类名
                if (parentName != null) {
                    // 传入了父分类名，则为添加子分类
                    // 根据父分类名找到父分类的cateId
                    Category parentCategory = new Category();
                    parentCategory.setName(parentName);
                    parentCategory = managerDao.selectCategoryByName(parentCategory);
                    // 检查是否能找到这个一级分类
                    if (parentCategory != null) {
                        // 找到了得到了parentCategory
                        category.setParentId(parentCategory.getCateId());
                        int count = managerDao.insertCategory(category);
                        if (count > 0) {
                            // 添加成功
                            return ResponseData.response(AddStatus.REQUEST_SUCCESS_200.status, AddStatus.REQUEST_SUCCESS_200.message, null);
                        }
                        // 添加失败
                        return ResponseData.response(AddStatus.REQUEST_ERROR_400.status, AddStatus.REQUEST_ERROR_400.message, null);
                    }
                    // 找不到该一级分类
                    return ResponseData.response(AddStatus.REQUEST_ERROR_400_2.status, AddStatus.REQUEST_ERROR_400_2.message, null);
                } else {
                    // 如果没有传入父分类名，则为添加父分类
                    category.setParentId(0);
                    int count = managerDao.insertCategory(category);
                    if (count > 0) {
                        // 添加成功
                        return ResponseData.response(AddStatus.REQUEST_SUCCESS_200.status, AddStatus.REQUEST_SUCCESS_200.message, null);
                    }
                    // 添加失败
                    return ResponseData.response(AddStatus.REQUEST_ERROR_400.status, AddStatus.REQUEST_ERROR_400.message, null);
                }
            }
            // 分类名存在，不可添加
            return ResponseData.response(AddStatus.REQUEST_ERROR_400_1.status, AddStatus.REQUEST_ERROR_400_1.message, null);
        }
        // token验证失败
        return ResponseData.response(AddStatus.REQUEST_ERROR_401.status, AddStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> modifyCategory(Category category, String token) {
        if (JwtToken.verifyToken(token) != null) {
            // 先检查要修改的分类名是否已存在
            List<Category> categoryList = managerDao.updateCheckCategoryName(category);
            if (categoryList.size() == 0) {
                // 分类名不存在，可以修改
                int count = managerDao.updateCategory(category);
                if (count > 0) {
                    // 修改成功
                    return ResponseData.response(ModifyStatus.REQUEST_SUCCESS_200.status, ModifyStatus.REQUEST_SUCCESS_200.message, null);
                }
                // 修改失败
                return ResponseData.response(ModifyStatus.REQUEST_ERROR_400.status, ModifyStatus.REQUEST_ERROR_400.message, null);
            }
            // 分类名存在，不可修改
            return ResponseData.response(ModifyStatus.REQUEST_ERROR_400_2.status, ModifyStatus.REQUEST_ERROR_400_2.message, null);
        }
        // token验证失败
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_401.status, ModifyStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> setProductStatus(Product product, String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            int count = managerDao.updateProductStatus(product);
            // 检查是否修改成功
            if (count > 0) {
                // 修改成功
                return ResponseData.response(ModifyStatus.REQUEST_SUCCESS_200.status, ModifyStatus.REQUEST_SUCCESS_200.message, null);
            }
            // 修改失败
            return ResponseData.response(ModifyStatus.REQUEST_ERROR_400.status, ModifyStatus.REQUEST_ERROR_400.message, null);
        }
        // token验证失败
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_401.status, ModifyStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> deleteProduct(Product product, String token) {
        if (JwtToken.verifyToken(token) != null) {
            int count = managerDao.deleteProduct(product);
            if (count > 0) {
                return ResponseData.response(DeleteStatus.REQUEST_SUCCESS_200.status, DeleteStatus.REQUEST_SUCCESS_200.message, null);
            }
            return ResponseData.response(DeleteStatus.REQUEST_ERROR_400.status, DeleteStatus.REQUEST_ERROR_400.message, null);
        }
        // token验证失败
        return ResponseData.response(ModifyStatus.REQUEST_ERROR_401.status, ModifyStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> addProduct(Product product, String cateName, String token) {
        if (JwtToken.verifyToken(token) != null) {
            // 先检查要添加商品所属的分类名是否已存在
            Category category = new Category();
            category.setName(cateName);
            List<Category> categoryList = managerDao.insertCheckCategoryName(category);
            if (categoryList.size() > 0) {
                // 分类名存在，可以添加商品
                category = categoryList.get(0);
                product.setCateId(category.getCateId());
                int count = managerDao.insertProduct(product);
                if (count > 0) {
                    return ResponseData.response(AddStatus.REQUEST_SUCCESS_200.status, AddStatus.REQUEST_SUCCESS_200.message, null);
                }
                return ResponseData.response(AddStatus.REQUEST_ERROR_400.status, AddStatus.REQUEST_ERROR_400.message, null);
            }
            // 分类名不存在，不可添加
            return ResponseData.response(AddStatus.REQUEST_ERROR_400_3.status, AddStatus.REQUEST_ERROR_400_3.message, null);
        }
        // token验证失败
        return ResponseData.response(AddStatus.REQUEST_ERROR_401.status, AddStatus.REQUEST_ERROR_401.message, null);

    }

    @Override
    public Map<String, Object> searchCategory(Category category, String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            List<Category> categoryList = managerDao.selectCategoryLike(category);
            // 检查是否查找成功
            if (categoryList.size() != 0) {
                // 查找成功
                return ResponseData.response(SearchStatus.REQUEST_SUCCESS_200.status, SearchStatus.REQUEST_SUCCESS_200.message, categoryList);
            }
            // 查找失败，找不到分类
            return ResponseData.response(SearchStatus.REQUEST_ERROR_400_3.status, SearchStatus.REQUEST_ERROR_400_3.message, null);
        }
        // token验证失败
        return ResponseData.response(SearchStatus.REQUEST_ERROR_401.status, SearchStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> searchProduct(Product product, String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            List<Product> productList = managerDao.selectProductLike(product);
            // 检查是否查找成功
            if (productList.size() != 0) {
                // 查找成功
                return ResponseData.response(SearchStatus.REQUEST_SUCCESS_200.status, SearchStatus.REQUEST_SUCCESS_200.message, productList);
            }
            // 查找失败，找不到商品
            return ResponseData.response(SearchStatus.REQUEST_ERROR_400_4.status, SearchStatus.REQUEST_ERROR_400_4.message, null);
        }
        // token验证失败
        return ResponseData.response(SearchStatus.REQUEST_ERROR_401.status, SearchStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> showSecCategory(Category category, String token) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            List<Category> categoryList = managerDao.selectSecCategory(category);
            System.out.println(categoryList);
            // 查找成功
            return ResponseData.response(SearchStatus.REQUEST_SUCCESS_200.status, SearchStatus.REQUEST_SUCCESS_200.message, categoryList);
        }
        // token验证失败
        return ResponseData.response(SearchStatus.REQUEST_ERROR_401.status, SearchStatus.REQUEST_ERROR_401.message, null);
    }

    @Override
    public Map<String, Object> uploadImage(String token, MultipartFile image, String pathRoot) {
        // 验证管理员的token
        if (JwtToken.verifyToken(token) != null) {
            String path = "";
            //生成uuid作为文件名称
            String uuid = UUID.randomUUID().toString().replaceAll("-", "");
            //获得文件类型（可以判断如果不是图片，禁止上传）
            String contentType = image.getContentType();
            //获得文件后缀名称
            String imageName = contentType.substring(contentType.indexOf("/") + 1);
            path = "/static/images/" + uuid + "." + imageName;
            try {
                image.transferTo(new File(pathRoot + path));
                System.out.println(path);
                Map<String, String> mainImage = new HashMap<>();
                mainImage.put("mainImage", path);
                return ResponseData.response(AddStatus.REQUEST_SUCCESS_200.status, AddStatus.REQUEST_SUCCESS_200.message, mainImage);
            } catch (IOException e) {
                e.printStackTrace();
                return ResponseData.response(AddStatus.REQUEST_ERROR_400.status, AddStatus.REQUEST_ERROR_400.message, null);
            }
        }
        // token验证失败
        return ResponseData.response(AddStatus.REQUEST_ERROR_401.status, AddStatus.REQUEST_ERROR_401.message, null);
    }


}
