package org.mousetailjuice.service.Impl;

import com.auth0.jwt.interfaces.Claim;
import org.mousetailjuice.dao.UserDao;
import org.mousetailjuice.entity.User;
import org.mousetailjuice.service.UserService;
import org.mousetailjuice.status.LoginStatus;
import org.mousetailjuice.status.LogoutStatus;
import org.mousetailjuice.status.RegisterStatus;
import org.mousetailjuice.util.JwtToken;
import org.mousetailjuice.util.ResponseData;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;

    @Override
    public Map<String, Object> userRegister(User user) {
        // 检查用户名是否重复
        if (userDao.registerSelectUser(user).size() == 0) {
            // 用户名不重复，可以注册
            int count = userDao.insertUser(user);
            if (count > 0) {
                // 注册成功
                return ResponseData.response(RegisterStatus.REQUEST_SUCCESS_200.status, RegisterStatus.REQUEST_SUCCESS_200.message, null);
            }
            // 注册失败
            return ResponseData.response(RegisterStatus.REQUEST_ERROR_400.status, RegisterStatus.REQUEST_ERROR_400.message, null);
        }
        // 用户名重复，注册失败
        return ResponseData.response(RegisterStatus.REQUEST_ERROR_400_1.status, RegisterStatus.REQUEST_ERROR_400_1.message, null);

    }

    @Override
    public Map<String, Object> userLogin(User user) {
        // 检查用户是否存在
        if (userDao.LoginSelectUser(user).size() != 0) {
            // 用户存在，更新用户的token
            String token = JwtToken.createToken(user.getUsername());
            user.setToken(token);
            int count = userDao.updateToken(user);
            // 检查更新token是否成功
            if (count > 0) {
                // token更新成功
                Map<String, Object> dataMap = new HashMap<>();
                dataMap.put("token", token);
                // 返回token
                return ResponseData.response(LoginStatus.REQUEST_SUCCESS_200.status, LoginStatus.REQUEST_SUCCESS_200.message, dataMap);
            }
            // token更新失败
            return ResponseData.response(LoginStatus.REQUEST_ERROR_401.status, LoginStatus.REQUEST_ERROR_401.message, null);
        }
        // 账户或密码错误
        return ResponseData.response(LoginStatus.REQUEST_ERROR_400.status, LoginStatus.REQUEST_ERROR_400.message, null);
    }

    @Override
    public Map<String, Object> userLogout(String token) {
        // 取得token里的用户名，删除用户的token
        Map<String, Claim> claimMap = JwtToken.verifyToken(token);
        if (claimMap != null) {
            User user = new User();
            user.setUsername(claimMap.get("username").asString());
            user.setToken(null);
            int count = userDao.updateToken(user);
            if (count > 0) {
                return ResponseData.response(LogoutStatus.REQUEST_SUCCESS_200.status, LogoutStatus.REQUEST_SUCCESS_200.message, null);
            }
            return ResponseData.response(LogoutStatus.REQUEST_ERROR_400.status, LogoutStatus.REQUEST_ERROR_400.message, null);
        }
        return ResponseData.response(LogoutStatus.REQUEST_ERROR_401.status, LogoutStatus.REQUEST_ERROR_401.message, null);

    }

}
