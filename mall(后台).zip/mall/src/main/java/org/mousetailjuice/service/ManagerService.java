package org.mousetailjuice.service;

import org.mousetailjuice.entity.Category;
import org.mousetailjuice.entity.Manager;
import org.mousetailjuice.entity.Product;
import org.mousetailjuice.entity.User;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.Map;

public interface ManagerService {
    /**
     * 对管理员登录的业务处理
     * @param manager 管理员对象
     * @return 响应数据
     */
    Map<String, Object> managerLogin(Manager manager);

    /**
     * 对获取所有用户信息的业务处理
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    Map<String, Object> showAllUsers(String token);

    /**
     * 对修改某个用户的状态的业务处理
     * @param user 用户对象
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    Map<String, Object> setUserStatus(User user, String token);

    /**
     * 对模糊查询用户的业务处理
     * @param user 用户对象
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    Map<String, Object> searchUser(User user, String token);

    /**
     * 对获取所有一级分类信息的业务处理
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    Map<String, Object> showAllCategories(String token);

    /**
     * 对删除分类信息的业务处理
     * @param token 管理员的token令牌
     * @return 响应数据
     */
    Map<String, Object> deleteCategory(Category category, String token);

    /**
     * 对查询所有商品的业务处理
     * @param token
     * @return
     */
    Map<String, Object> showAllProducts(String token);

    /**
     * 添加类别的业务处理
     * @param category 类别对象
     * @param parentName 该类别的父类别，可能为空
     * @param token
     * @return
     */
    Map<String, Object> addCategory(Category category, String parentName, String token);

    /**
     * 修改类别信息的业务处理
     * @param category
     * @param token
     * @return
     */
    Map<String, Object> modifyCategory(Category category, String token);

    /**
     * 对商品上下架的业务处理
     * @param product
     * @param token
     * @return
     */
    Map<String, Object> setProductStatus(Product product, String token);

    /**
     * 对删除商品的业务处理
     * @param product
     * @param token
     * @return
     */
    Map<String, Object> deleteProduct(Product product, String token);

    /**
     * 对添加商品的业务处理
     * @param product
     * @param cateName
     * @param token
     * @return
     */
    Map<String, Object> addProduct(Product product, String cateName, String token);

    /**
     * 对搜索分类的业务处理
     * @param category
     * @param token
     * @return
     */
    Map<String, Object> searchCategory(Category category, String token);

    /**
     * 对搜索商品的业务处理
     * @param product
     * @param token
     * @return
     */
    Map<String, Object> searchProduct(Product product, String token);

    /**
     * 查询一级分类下的二级分类
     * @param category
     * @param token
     * @return
     */
    Map<String, Object> showSecCategory(Category category, String token);

    /**
     * 上传图片的业务处理
     * @param image
     * @param pathRoot
     * @return
     */
    Map<String, Object> uploadImage(String token, MultipartFile image, String pathRoot);
}
