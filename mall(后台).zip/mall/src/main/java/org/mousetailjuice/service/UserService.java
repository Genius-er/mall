package org.mousetailjuice.service;

import org.mousetailjuice.entity.User;

import java.util.Map;

public interface UserService {
    /**
     * 对用户注册的业务处理
     * @param user
     * @return
     */
    Map<String, Object> userRegister(User user);

    /**
     * 对用户登录的业务处理
     * @param user
     * @return
     */
    Map<String, Object> userLogin(User user);

    /**
     * 对用户注销的业务处理
     * @param token
     * @return
     */
    Map<String, Object> userLogout(String token);
}
