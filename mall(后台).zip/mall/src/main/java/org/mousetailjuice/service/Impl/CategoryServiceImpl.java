package org.mousetailjuice.service.Impl;

import org.mousetailjuice.dao.CategoryDao;
import org.mousetailjuice.entity.Product;
import org.mousetailjuice.service.CategoryService;
import org.mousetailjuice.status.CommonStatus;
import org.mousetailjuice.util.ResponseData;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Resource
    private CategoryDao categoryDao;

    @Override
    public Map<String, Object> getAllCategories() {
        List<Map<String, Object>> firstCategoryList = categoryDao.selectAllFirstCategories();
        for (Map<String, Object> firstCategory : firstCategoryList) {
            Integer cateId = (Integer) firstCategory.get("cateId");
            List<Map<String, Object>> secondCategoryList = categoryDao.selectSecondCategories(cateId);
            firstCategory.put("secondCategory", secondCategoryList);
        }
        return ResponseData.response(CommonStatus.REQUEST_SUCCESS_200.status, CommonStatus.REQUEST_SUCCESS_200.message, firstCategoryList);
    }


}
