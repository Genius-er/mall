package org.mousetailjuice.service.Impl;

import org.mousetailjuice.dao.ProductDao;
import org.mousetailjuice.entity.Category;
import org.mousetailjuice.entity.Product;
import org.mousetailjuice.service.ProductService;
import org.mousetailjuice.status.CommonStatus;
import org.mousetailjuice.status.SearchStatus;
import org.mousetailjuice.util.ResponseData;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class ProductServiceImpl implements ProductService {
    @Resource
    private ProductDao productDao;

    @Override
    public Map<String, Object> getHotProducts() {
        List<Map<String, Object>> productList = productDao.selectHotProducts();
        return ResponseData.response(CommonStatus.REQUEST_SUCCESS_200.status, CommonStatus.REQUEST_SUCCESS_200.message, productList);
    }

    @Override
    public Map<String, Object> getProductsByCateId(Integer cateId) {
        // 检查是否为一级分类
        Category category = productDao.checkCateLevel(cateId);
        List<Map<String, Object>> productList;
        if (category.getParentId() == 0) {
            // 根据一级分类的cateId选择属于一级分类的商品
            productList = productDao.selectProductByFirCateId(cateId);
        } else {
            // 根据二级分类的cateId选择属于二级分类的商品
            productList = productDao.selectProductBySecCateId(cateId);
        }
        return ResponseData.response(SearchStatus.REQUEST_SUCCESS_200.status, SearchStatus.REQUEST_SUCCESS_200.message, productList);
    }

    @Override
    public Map<String, Object> getProductInfo(Integer proId) {
        Map<String, Object> productInfo = productDao.selectProductByProId(proId);
        return ResponseData.response(SearchStatus.REQUEST_SUCCESS_200.status, SearchStatus.REQUEST_SUCCESS_200.message, productInfo);
    }


}
