package org.mousetailjuice.service;

import java.util.Map;

public interface ProductService {
    /**
     * 获取所有的商品
     * @return
     */
    Map<String, Object> getHotProducts();

    /**
     * 获取指定一级分类下的所有商品
     * @return
     */
    Map<String, Object> getProductsByCateId(Integer cateId);

    /**
     * 获取商品信息
     * @param proId
     * @return
     */
    Map<String, Object> getProductInfo(Integer proId);
}
