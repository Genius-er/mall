package org.mousetailjuice.service;

import java.util.List;
import java.util.Map;

public interface CategoryService {
    /**
     * 获取所有一级分类及其对应的二级分类
     * @return
     */
    Map<String, Object> getAllCategories();


}
