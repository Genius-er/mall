package org.mousetailjuice.entity;

import java.util.Objects;

public class Manager {
    private Integer userId;
    private String username;
    private String password;
    private String token;

    public Manager() {
    }

    public Manager(Integer userId, String username, String password, String token) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.token = token;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Manager manager = (Manager) o;
        return Objects.equals(userId, manager.userId) &&
                Objects.equals(username, manager.username) &&
                Objects.equals(password, manager.password) &&
                Objects.equals(token, manager.token);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, username, password, token);
    }

    @Override
    public String toString() {
        return "Manager{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", token='" + token + '\'' +
                '}';
    }
}
