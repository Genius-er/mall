package org.mousetailjuice.entity;

import java.util.Objects;

public class Category {
    private Integer cateId;
    private Integer parentId;
    private String name;
    private String description;
    private String createTime;
    private String updateTime;

    public Category() {
    }

    public Category(Integer cateId, Integer parentId, String name, String description, String createTime, String updateTime) {
        this.cateId = cateId;
        this.parentId = parentId;
        this.name = name;
        this.description = description;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public Integer getCateId() {
        return cateId;
    }

    public void setCateId(Integer cateId) {
        this.cateId = cateId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Category category = (Category) o;
        return Objects.equals(cateId, category.cateId) &&
                Objects.equals(parentId, category.parentId) &&
                Objects.equals(name, category.name) &&
                Objects.equals(description, category.description) &&
                Objects.equals(createTime, category.createTime) &&
                Objects.equals(updateTime, category.updateTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cateId, parentId, name, description, createTime, updateTime);
    }

    @Override
    public String toString() {
        return "Category{" +
                "cateId=" + cateId +
                ", parentId=" + parentId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", createTime='" + createTime + '\'' +
                ", updateTime='" + updateTime + '\'' +
                '}';
    }
}
