package org.mousetailjuice.entity;

import java.util.Objects;

public class Product {
    private Integer proId;
    private Integer cateId;
    private String cateName;
    private String name;
    private String mainImage;
    private String detail;
    private Double price;
    private Integer stock;
    private int status;
    private String createTime;
    private String updateTime;

    public Product() {
    }

    public Product(Integer proId, Integer cateId, String cateName, String name, String mainImage, String detail, Double price, Integer stock, int status, String createTime, String updateTime) {
        this.proId = proId;
        this.cateId = cateId;
        this.cateName = cateName;
        this.name = name;
        this.mainImage = mainImage;
        this.detail = detail;
        this.price = price;
        this.stock = stock;
        this.status = status;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public Integer getProId() {
        return proId;
    }

    public void setProId(Integer proId) {
        this.proId = proId;
    }

    public Integer getCateId() {
        return cateId;
    }

    public void setCateId(Integer cateId) {
        this.cateId = cateId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMainImage() {
        return mainImage;
    }

    public void setMainImage(String mainImage) {
        this.mainImage = mainImage;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getCateName() {
        return cateName;
    }

    public void setCateName(String cateName) {
        this.cateName = cateName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return status == product.status &&
                Objects.equals(proId, product.proId) &&
                Objects.equals(cateId, product.cateId) &&
                Objects.equals(cateName, product.cateName) &&
                Objects.equals(name, product.name) &&
                Objects.equals(mainImage, product.mainImage) &&
                Objects.equals(detail, product.detail) &&
                Objects.equals(price, product.price) &&
                Objects.equals(stock, product.stock) &&
                Objects.equals(createTime, product.createTime) &&
                Objects.equals(updateTime, product.updateTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(proId, cateId, cateName, name, mainImage, detail, price, stock, status, createTime, updateTime);
    }

    @Override
    public String toString() {
        return "Product{" +
                "proId=" + proId +
                ", cateId=" + cateId +
                ", cateName=" + cateName +
                ", name='" + name + '\'' +
                ", mainImage='" + mainImage + '\'' +
                ", detail='" + detail + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                ", status=" + status +
                ", createTime='" + createTime + '\'' +
                ", updateTime='" + updateTime + '\'' +
                '}';
    }
}
