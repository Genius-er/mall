package org.mousetailjuice.util;

import java.util.HashMap;
import java.util.Map;

/**
 *  响应数据工具类
 *  用于返回状态码、状态信息、数据
 */
public class ResponseData {
    public static Map<String, Object> response(String status, String message, Object data) {
        Map<String, Object> result = new HashMap<>();
        result.put("code", status);
        result.put("msg", message);
        result.put("data", data);
        return result;
    }
}
